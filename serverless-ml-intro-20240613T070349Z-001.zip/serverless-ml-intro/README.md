create virual envirionment.

Follow the instructions on lab doc
